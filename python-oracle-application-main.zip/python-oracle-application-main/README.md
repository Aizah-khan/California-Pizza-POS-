# python-oracle-application
Instructions:
Requirements:
1-oracle 12c installed in the system
2- Python 3.5 or greater
3- cx_Oracle python module should be installed 
2-create user 
user: project
password: 12345
host: 1522
pluggable database: pdborcl

3-Run attached schema and insertion script in oracle 12c

connection creation: project/12345@//localhost:1522/pdborcl
4- Run the exe file 
