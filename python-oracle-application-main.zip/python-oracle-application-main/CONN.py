import cx_Oracle

connection = cx_Oracle.connect('project/12345@//localhost:1522/pdborcl')
cursor = connection.cursor()




